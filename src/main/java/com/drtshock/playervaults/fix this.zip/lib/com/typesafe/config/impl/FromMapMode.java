/**
 *   Copyright (C) 2011-2012 Typesafe Inc. <http://typesafe.com>
 */
package com.drtshock.playervaults.lib.com.typesafe.config.impl;

enum FromMapMode {
    KEYS_ARE_PATHS, KEYS_ARE_KEYS
}
