package com.drtshock.playervaults.lib.com.typesafe.config.impl;

// caution: ordinals used in serialization
enum OriginType {
    GENERIC,
    FILE,
    URL,
    RESOURCE
}
