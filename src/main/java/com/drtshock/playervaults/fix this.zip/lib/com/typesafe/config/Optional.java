package com.drtshock.playervaults.lib.com.typesafe.config;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Allows an config property to be {@code null}.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Optional {

}
