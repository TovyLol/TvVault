package com.drtshock.playervaults.lib.com.typesafe.config.impl;

enum ConfigIncludeKind {
    URL, FILE, CLASSPATH, HEURISTIC
}
